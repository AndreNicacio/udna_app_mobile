const axios = require('axios');

const devURLBase = 'https://gateway.dev.liftpay.com.br/v1/payment';
const prdURLBase = 'https://gateway.liftpay.com.br/v1/payment';
const devAPIKey = 'MzI3NjExNDIwMDAxNjg6TWpNek1ETXlNRE02ZEdWemRIQmhjM04zYjNKa1gwdFFPV2hyT0VkclpFbFdXbnBOVWpKSlVXRXlhRXBVVURGaWNHSkhlV3RPUVRadGFVMVNPRzFVZHpWYWF3PT0=';
const prdAPIKey = 'MzczMTUwMjQwMDAxNDA6T1RZMU16a3pOelk2Y0hKdlpIQmhjM04zYjNKa1gybHhZbTE2VlVoWlNUQXpiRGxUU1VWV1ptWjZia0V4Tm1Kb1UyUlhNWEpoV2paT1dtWklibkJDTVhwalNnPT0=';

const paymentAPI = axios.create({
  baseURL: process.env.ENV === 'dev' ? devURLBase : prdURLBase,
  headers: {'Authorization': `Basic ${process.env.ENV === 'dev' ? devAPIKey : prdAPIKey}`},
  timeout: 15000,
});

module.exports = { paymentAPI };
