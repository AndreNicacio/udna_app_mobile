/* Amplify Params - DO NOT EDIT
You can access the following resource attributes as environment variables from your Lambda function
var environment = process.env.ENV
var region = process.env.REGION
var authUdnabackendbe02c040UserPoolId = process.env.AUTH_UDNABACKENDBE02C040_USERPOOLID
var apiUdnaBackendGraphQLAPIIdOutput = process.env.API_UDNABACKEND_GRAPHQLAPIIDOUTPUT
var apiUdnaBackendGraphQLAPIEndpointOutput = process.env.API_UDNABACKEND_GRAPHQLAPIENDPOINTOUTPUT

Amplify Params - DO NOT EDIT */

const { paymentAPI } = require('./paymentClient');

const STATUS = {
  unpaid: {
    text: 'Esperando pagamento',
    color: '#3E7AB6',
  },
  paid: {
    text: 'Pago',
    color: '#85bc96',
  },
};

exports.handler = async (event) => {
  const { username } = event.arguments;

  try {
    const res = await paymentAPI.get('/checkout');
    const results = res.data.items.filter(elt => {
      if (elt.metadata && elt.metadata.username && username === elt.metadata.username) {
        return true;
      }
      return false;
    }).map(elt => ({
      id: elt.id,
      examId: elt.metadata.examId,
      title: elt.metadata.examTitle,
      price: elt.metadata.examPrice,
      status: STATUS[elt.orderStatus.toLowerCase()] || {
        text: 'Sem status',
        color: '#000000'
      },
      date: elt.createdAt,
    }))
    return results;
  } catch (error) {
    return [{
      error: error.toString(),
    }];
  }
};
