/* Amplify Params - DO NOT EDIT
You can access the following resource attributes as environment variables from your Lambda function
var environment = process.env.ENV
var region = process.env.REGION
var authUdnabackendbe02c040UserPoolId = process.env.AUTH_UDNABACKENDBE02C040_USERPOOLID
var apiUdnaBackendGraphQLAPIIdOutput = process.env.API_UDNABACKEND_GRAPHQLAPIIDOUTPUT
var apiUdnaBackendGraphQLAPIEndpointOutput = process.env.API_UDNABACKEND_GRAPHQLAPIENDPOINTOUTPUT
var functionBuyExamBilletName = process.env.FUNCTION_BUYEXAMBILLET_NAME

Amplify Params - DO NOT EDIT */

const { paymentAPI } = require('./paymentClient');

exports.handler = async (event) => {
  const {
    user, exam, card,
  } = event.arguments;

  const cardExpiry = card.expiry.split('/');

  const body = {
    amount: exam.price,
    currency: "BRL",
    cardInfo: {
      pan: card.number.replace(/\s+/g, ''),
      expiryMonth: cardExpiry[0],
      expiryYear: cardExpiry[1],
      securityCode: card.cvc,
      cardHolderName: card.name,
      installmentNumber: card.installments.toString()
    },
    customer: {
      email: user.email,
    },
    metadata:{
      username: user.cpf.replace(/\D/g, ''),
      examId: exam.id,
      examTitle: exam.title,
      examPrice: exam.price,
    }
  }
  try {
    const res = await paymentAPI.post('/checkout', body);
    return res.data.url ? res.data.url : null;
  } catch (error) {
    return error.toString();
  }
};
