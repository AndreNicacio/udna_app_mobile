const axios = require('axios');

const pagarmeAPI = axios.create({
  baseURL: 'https://api.pagar.me/1',
  timeout: 5000,
});

const PAGARME_API_KEY_DEV = 'ak_test_ulsA1wRzeilVFLFt7qLSgz9AvBZLwI';
const PAGARME_API_KEY_PRD = 'ak_live_Sw8cG8pFXru7ryrQJCbers3dWcNd8o';

module.exports = { pagarmeAPI, PAGARME_API_KEY_DEV, PAGARME_API_KEY_PRD };
